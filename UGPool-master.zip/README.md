Pytorch implementation of Uniform Pooling for Graph Networks
====


## Requirements

  * torch_geometric
  * torch

## Usage

```python main.py```


## Cite
```
@journal{JianQ2020,
  title = 	 {Uniform Pooling for Graph Networks},
  author = 	 {Jian Qin, Li Liu, Hui Shen, Dewen Hu*},
}
```
