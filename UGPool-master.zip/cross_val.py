import networkx as nx
import numpy as np
import torch

import transmat
import scipy.io as sio

class GraphDataset(torch.utils.data.Dataset):
    ''' Sample graphs and nodes in graph
    '''
    def __init__(self, files,node_num):
        self.files = files
        self.node_num = node_num

    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        
        feature, label, subject_id = transmat.loadmat(self.files[idx])
        label[label==-1]=0
        if feature.shape[0]>1:
            feature = feature.T
        feature = transmat.triu2mat(feature, self.node_num)
        return feature, label, subject_id

class GraphDataset_centors(torch.utils.data.Dataset):
    ''' Sample graphs and nodes in graph
    '''
    def __init__(self, files,node_num,centors):
        self.files = files
        self.node_num = node_num
        self.centors = centors

    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        
        feature, _ = transmat.loadmat(self.files[idx])
        label = self.centors[idx]
        feature = transmat.triu2mat(feature, self.node_num)
        return feature, label

def cross_val_index(randind,vidx,vnum=10):
    vsize = len(randind) // vnum
    indtest = randind[vsize*vidx:vsize*vidx+vsize]
    indtrain = np.delete(randind,np.s_[vsize*vidx:vsize*vidx+vsize],axis=0)  
    return indtrain,indtest

def cross_val_test_index(randind,vidx):
    
    num_test = int(len(randind)*0.1)
    num_training = int(len(randind)*0.8)
    
    f=vidx
    indtest = randind[f*num_test:f*num_test+num_test]
    indremain = np.delete(randind,np.s_[f*num_test:f*num_test+num_test],axis=0)
    indtrain = indremain[:num_training]
    indval = indremain[num_training:]
    
    return indtrain, indval, indtest, 
    

def prepare_val_data(files, subject_id, rand_uniq_subject, batch_size, val_idx, node_num, num_workers=0):

    train_sub, val_sub, test_sub = cross_val_test_index(rand_uniq_subject,val_idx)
    
    indtest = np.isin(subject_id,test_sub)
    indval = np.isin(subject_id,val_sub)
    indtrain = np.isin(subject_id,train_sub)
    
    idx_test = np.where(indtest)[0]
    file_test = np.array(files)[idx_test].tolist()
    idx_val = np.where(indval)[0]
    file_val = np.array(files)[idx_val].tolist()
    idx_train = np.where(indtrain)[0]
    file_train = np.array(files)[idx_train].tolist()
    

    
    # minibatch
    dataset_sampler = GraphDataset(file_train,node_num)
    train_dataset_loader = torch.utils.data.DataLoader(
            dataset_sampler, 
            batch_size=batch_size, 
            shuffle=True,
            num_workers=num_workers)
    
    dataset_sampler = GraphDataset(file_val,node_num)
    val_dataset_loader = torch.utils.data.DataLoader(
            dataset_sampler,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers)

    dataset_sampler = GraphDataset(file_test,node_num)
    test_dataset_loader = torch.utils.data.DataLoader(
            dataset_sampler, 
            batch_size=batch_size, 
            shuffle=False,
            num_workers=num_workers)

    return train_dataset_loader, val_dataset_loader, test_dataset_loader

def prepare_only_val_data(files, subject_id, rand_uniq_subject, batch_size, val_idx, node_num, num_workers=0):

    train_sub, val_sub = cross_val_index(rand_uniq_subject,val_idx)
    

    indval = np.isin(subject_id,val_sub)
    indtrain = np.isin(subject_id,train_sub)
    
    idx_val = np.where(indval)[0]
    file_val = np.array(files)[idx_val].tolist()
    idx_train = np.where(indtrain)[0]
    file_train = np.array(files)[idx_train].tolist()
    

    
    # minibatch
    dataset_sampler = GraphDataset(file_train,node_num)
    train_dataset_loader = torch.utils.data.DataLoader(
            dataset_sampler, 
            batch_size=batch_size, 
            shuffle=True,
            num_workers=num_workers)
    
    dataset_sampler = GraphDataset(file_val,node_num)
    val_dataset_loader = torch.utils.data.DataLoader(
            dataset_sampler,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers)
    test_dataset_loader = None

    return train_dataset_loader, val_dataset_loader, test_dataset_loader

def prepare_all_data(files, batch_size, node_num, num_workers=0):
    
    dataset_sampler = GraphDataset(files,node_num)
    train_dataset_loader = torch.utils.data.DataLoader(
            dataset_sampler,batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers)
    return train_dataset_loader

def prepare_val_data_ct(centors, files, subject_id, rand_uniq_subject, batch_size, val_idx, node_num, num_workers=0):

    train_sub, test_sub = cross_val_index(rand_uniq_subject,val_idx)
    
    indtest = np.isin(subject_id,test_sub)
    indtrain = np.isin(subject_id,train_sub)
    
    idx_test = np.where(indtest)[0]
    file_test = np.array(files)[idx_test].tolist()
    idx_train = np.where(indtrain)[0]
    file_train = np.array(files)[idx_train].tolist()
    
    centors_test = np.array(centors)[idx_test].tolist()
    centors_train = np.array(centors)[idx_train].tolist()

    
    # minibatch
    dataset_sampler = GraphDataset_centors(file_train,node_num,centors_train)
    train_dataset_loader = torch.utils.data.DataLoader(
            dataset_sampler, 
            batch_size=batch_size, 
            shuffle=True,
            num_workers=num_workers)

    dataset_sampler = GraphDataset_centors(file_test,node_num,centors_test)
    val_dataset_loader = torch.utils.data.DataLoader(
            dataset_sampler, 
            batch_size=batch_size, 
            shuffle=False,
            num_workers=num_workers)

    return train_dataset_loader, val_dataset_loader

def prepare_all_data_ct(centors,files, batch_size, node_num, num_workers=0):
    
    dataset_sampler = GraphDataset_centors(files,node_num,centors)
    train_dataset_loader = torch.utils.data.DataLoader(
            dataset_sampler,batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers)
    return train_dataset_loader