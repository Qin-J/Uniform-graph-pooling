"""
@author: Jian Qin , changsha
"""


import torch
import torch.nn.functional as F
from torch.nn import Parameter

from torch_geometric.nn import GCNConv
from torch_geometric.nn import global_mean_pool as gap, global_max_pool as gmp
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.nn.pool.topk_pool import filter_adj,uniform
from torch_geometric.utils import softmax



class UGPool(MessagePassing):
    def __init__(self, in_channels, ratio=0.5, min_score=None, multiplier=1,
                 nonlinearity=torch.tanh):
        super(UGPool, self).__init__()

        self.in_channels = in_channels
        self.ratio = ratio
        self.min_score = min_score
        self.multiplier = multiplier
        self.nonlinearity = nonlinearity

        self.weight = Parameter(torch.Tensor(1, in_channels))
        # self.score_layer = GCNConv(in_channels,1)

        self.reset_parameters()

    def reset_parameters(self):
        size = self.in_channels
        uniform(size, self.weight)

    def slice_pool(self, score, batch):

        uniq_batch, uniq_counts = torch.unique(batch, return_counts=True)
        remain_batch = uniq_batch[uniq_counts <= 2]
        slice_batch = uniq_batch[uniq_counts > 2]
        remain_perm = []
        for i in remain_batch:
            remain_perm.extend(torch.nonzero(batch == i))
        if len(remain_perm) > 0:
            remain_perm = torch.cat(remain_perm)

        perm = []
        for i in slice_batch:
            _, sort_index = torch.sort(score[batch == i])
            perm.extend(torch.nonzero(batch == i)[sort_index])

        if len(perm) > 0:
            perm = torch.cat(perm)[::2]

        if len(remain_perm) > 0 and len(perm) > 0:
            perm = torch.cat([perm, remain_perm])
        elif len(perm) == 0:
            perm = remain_perm
        else:
            None

        return perm

    def forward(self, x, edge_index, edge_attr=None, batch=None, attn=None):
        """"""

        if batch is None:
            batch = edge_index.new_zeros(x.size(0))

        attn = x if attn is None else attn
        attn = attn.unsqueeze(-1) if attn.dim() == 1 else attn
        score = (attn * self.weight).sum(dim=-1)

        # x = self.propagate(edge_index=edge_index,x=x,norm=GCNConv.norm)
        # attn = torch.cat([attn,x],dim=1)
        # score = self.score_layer(attn,edge_index).squeeze()

        if self.min_score is None:
            score = self.nonlinearity(score / self.weight.norm(p=2, dim=-1))
        else:
            score = softmax(score, batch)

        perm = self.slice_pool(score, batch)
        x = x[perm] * score[perm].view(-1, 1)
        x = self.multiplier * x if self.multiplier != 1 else x

        batch = batch[perm]
        edge_index, edge_attr = filter_adj(edge_index, edge_attr, perm,
                                           num_nodes=score.size(0))
        return x, edge_index, edge_attr, batch, perm, score[perm]

    def __repr__(self):
        return '{}({}, {}={}, multiplier={})'.format(
            self.__class__.__name__, self.in_channels,
            'ratio' if self.min_score is None else 'min_score',
            self.ratio if self.min_score is None else self.min_score,
            self.multiplier)


class Net_UGPool_h(torch.nn.Module):
    def __init__(self, args):
        super(Net_UGPool_h, self).__init__()
        self.args = args
        self.num_features = args.num_features
        self.nhid = args.nhid
        self.num_classes = args.num_classes
        self.pooling_ratio = args.pooling_ratio
        self.dropout_ratio = args.dropout_ratio
        graphconv = GCNConv
        self.conv1 = graphconv(self.num_features, self.nhid)
        self.pool1 = UGPool(self.nhid, ratio=self.pooling_ratio)
        self.conv2 = graphconv(self.nhid, self.nhid)
        self.pool2 = UGPool(self.nhid, ratio=self.pooling_ratio)
        self.conv3 = graphconv(self.nhid, self.nhid)
        self.pool3 = UGPool(self.nhid, ratio=self.pooling_ratio)

        self.lin1 = torch.nn.Linear(self.nhid * 2, self.nhid)
        self.lin2 = torch.nn.Linear(self.nhid, self.nhid // 2)
        self.lin3 = torch.nn.Linear(self.nhid // 2, self.num_classes)

    def forward(self, data):
        x, edge_index, batch = data.x, data.edge_index, data.batch

        if len(x.size()) < 1:
            x.unsqueeze_(0)
        if len(edge_index.size()) < 1:
            edge_index.unsqueeze_(0)

        x = F.relu(self.conv1(x, edge_index))
        x, edge_index, _, batch, _, _ = self.pool1(x, edge_index, None, batch)
        x1 = torch.cat([gmp(x, batch), gap(x, batch)], dim=1)

        x = F.relu(self.conv2(x, edge_index))
        x, edge_index, _, batch, _, _ = self.pool2(x, edge_index, None, batch)
        x2 = torch.cat([gmp(x, batch), gap(x, batch)], dim=1)

        x = F.relu(self.conv3(x, edge_index))
        x, edge_index, _, batch, _, _ = self.pool3(x, edge_index, None, batch)
        x3 = torch.cat([gmp(x, batch), gap(x, batch)], dim=1)

        x = x1 + x2 + x3

        x = F.relu(self.lin1(x))
        x = F.dropout(x, p=self.dropout_ratio, training=self.training)
        x = F.relu(self.lin2(x))
        x = F.log_softmax(self.lin3(x), dim=-1)

        return x



class Net_UGPool_g(torch.nn.Module):
    def __init__(self, args):
        super(Net_UGPool_g, self).__init__()
        self.args = args
        self.num_features = args.num_features
        self.nhid = args.nhid
        self.num_classes = args.num_classes
        self.pooling_ratio = args.pooling_ratio
        self.dropout_ratio = args.dropout_ratio
        graphconv = GCNConv
        self.conv1 = graphconv(self.num_features, self.nhid)
        self.pool1 = UGPool(self.nhid, ratio=self.pooling_ratio)
        self.conv2 = graphconv(self.nhid, self.nhid)
        self.pool2 = UGPool(self.nhid, ratio=self.pooling_ratio)
        self.conv3 = graphconv(self.nhid, self.nhid)
        self.pool3 = UGPool(self.nhid, ratio=self.pooling_ratio)

        self.lin1 = torch.nn.Linear(self.nhid * 2, self.nhid)
        self.lin2 = torch.nn.Linear(self.nhid, self.nhid // 2)
        self.lin3 = torch.nn.Linear(self.nhid // 2, self.num_classes)

    def forward(self, data):
        x, edge_index, batch = data.x, data.edge_index, data.batch

        if len(x.size()) < 1:
            x.unsqueeze_(0)
        if len(edge_index.size()) < 1:
            edge_index.unsqueeze_(0)

        x = F.relu(self.conv1(x, edge_index))
        x1 = torch.cat([gmp(x, batch), gap(x, batch)], dim=1)
        x = F.relu(self.conv2(x, edge_index))
        x2 = torch.cat([gmp(x, batch), gap(x, batch)], dim=1)
        x = F.relu(self.conv3(x, edge_index))
        x3 = torch.cat([gmp(x, batch), gap(x, batch)], dim=1)

        # pooling
        if x.shape[0] > 5:
            x, edge_index, _, batch, _,_ = self.pool1(x, edge_index, None, batch)
        x4 = torch.cat([gmp(x, batch), gap(x, batch)], dim=1)

        x = x1 + x2 + x3 + x4

        x = F.relu(self.lin1(x))
        x = F.dropout(x, p=self.dropout_ratio, training=self.training)
        x = F.relu(self.lin2(x))
        x = F.log_softmax(self.lin3(x), dim=-1)

        return x