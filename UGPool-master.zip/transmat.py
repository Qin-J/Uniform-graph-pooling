#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Jian Qin, changsha
"""
import numpy as np
import tensorflow as tf
import h5py
import scipy.io as sio

def tril2mat(trilfeat,dim):
    index = np.ones((dim,dim))
    index = np.tril(index,-1)
    N,_ = trilfeat.shape
    matrix = np.zeros((N,dim,dim),dtype=trilfeat.dtype)
    for i in range(N):
        temp = np.zeros((dim,dim),dtype=trilfeat.dtype)
        temp[index==1]=trilfeat[i,:]
        temp = temp + temp.T
        matrix[i,:,:] = temp
    return matrix

def triu2mat(trilfeat,dim):
    index = np.ones((dim,dim))
    index = np.triu(index,1)
    N,_ = trilfeat.shape
    matrix = np.zeros((N,dim,dim),dtype=trilfeat.dtype)
    for i in range(N):
        temp = np.zeros((dim,dim),dtype=trilfeat.dtype)
        temp[index==1]=trilfeat[i,:]
        temp = temp + temp.T
        matrix[i,:,:] = temp
    return matrix


def tril2mat_tensor(trilfeat,dim):
    matrix=[]
    for i in range(dim):
        ed = int((dim-1 + dim-i-1)*(i+1)/2)
        st = int(ed-dim+i+1)
        colum = tf.concat([tf.zeros_like(trilfeat[...,0:i+1]),trilfeat[...,st:ed]],axis=-1)
        matrix.append(colum)
    matrix=tf.concat(matrix,axis=-1)
#    if len(trilfeat.shape)>1:
#        matrix=tf.reshape(matrix,[-1,dim,dim])
#    else:
#        matrix=tf.squeeze(tf.reshape(matrix,[-1,dim,dim]))
    
    matrix=tf.reshape(matrix,[-1,dim,dim])
    matrix=matrix+tf.transpose(matrix,perm=[0,2,1])
        
#    if len(trilfeat.shape)>1:
#        matrix=matrix+tf.transpose(matrix,perm=[0,2,1])
#    else:
#        matrix=matrix+tf.transpose(matrix,perm=[1,0])
    return matrix

def triu2mat_tensor(trilfeat,dim):
    matrix=[]
    for i in range(dim):
        ed = int((i+0)*(i+1)/2)
        st = int(ed-i)
        colum = tf.concat([trilfeat[...,st:ed],tf.zeros_like(trilfeat[...,0:dim-i])],axis=-1)
        matrix.append(colum)
    matrix=tf.concat(matrix,axis=-1)
    matrix=tf.squeeze(tf.reshape(matrix,[-1,dim,dim]))
    if len(trilfeat.shape)>1:
        matrix=matrix+tf.transpose(matrix,perm=[0,2,1])
    else:
        matrix=matrix+tf.transpose(matrix,perm=[1,0])
    return matrix

def loadmat(datafile):
    
    try:
        ### read genernal .mat file
        #datafile = '/home/qinjian/Disk/all_FC_HCP_176roi_rest1_LR_normlized.mat'
        data = sio.loadmat(datafile)
        X = data['static_R']
        label = data['label']
        if 'subject_id' in data.keys():
            subject_id = data['subject_id']
        else:
            subject_id = np.array(range(len(label))).reshape([-1,1])
    except:
        ## read -v7.3 .mat file
        data = h5py.File(datafile)
        X = np.transpose(data['static_R'])
        label = np.transpose(data['label'])
        if 'subject_id' in data.keys():
            subject_id = np.transpose(data['subject_id'])
        else:
            subject_id = np.array(range(len(label))).reshape([-1,1])
#        if max(subject_id.shape)>1:
        subject_id = bytes(subject_id[:]).decode('utf-16')
        subject_id = [subject_id]
       
    return X,label,subject_id

def loadmats(datafiles):
    
    Xs=[]
    labels=[]
    for datafile in datafiles:
        try:
            ### read genernal .mat file
            #datafile = '/home/qinjian/Disk/all_FC_HCP_176roi_rest1_LR_normlized.mat'
            data = sio.loadmat(datafile)
            X = data['static_R']
            label = data['label']
            if 'subject_id' in data.keys():
                subject_id = data['subject_id']
            else:
                subject_id = np.array(range(len(label))).reshape([-1,1])
        except:
            ## read -v7.3 .mat file
            data = h5py.File(datafile)
            X = np.transpose(data['static_R'])
            label = np.transpose(data['label'])
            if 'subject_id' in data.keys():
                subject_id = np.transpose(data['subject_id'])
            else:
                subject_id = np.array(range(len(label))).reshape([-1,1])
        Xs.extend(X)
        labels.extend(label)
    return np.array(Xs),np.array(labels)
